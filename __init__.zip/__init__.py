from flask import Flask, render_template
import webview
app = Flask(__name__)
webview.create_window("7DS Character base", app)

@app.route('/')
@app.route('/index')
def index():
    return render_template("index.html", title = "7DS characters")

@app.route('/meliodas')
def meliodas():
    return render_template("meliodas.html", title = "Meliodas")

@app.route('/form')
def form():
    return render_template("form.html", title = "ability form")

if __name__== "__main__":
    #app.debug = True
    #app.run()
    webview.start()
