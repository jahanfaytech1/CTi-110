from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template("index.html", title = "7DS characters")

@app.route('/meliodas')
def meliodas():
    return render_template("meliodas.html", title = "Meliodas")

@app.route('/form')
def form():
    return render_template("form.html", title = "ability form")

if __name__== "__main__":
    app.debug = True
    app.run()
