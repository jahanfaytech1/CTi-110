from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
    return render_template("index.html", title = "7DS characters")

@app.route('/meliodas')
def meliodas():
    return "meliodas's page"

if __name__== "__main__":
    app.debug = True
    app.run()
